import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { format } from "date-fns";
import { Event, Attendee } from "@shared/schema";
import { queryClient } from "@/lib/queryClient";
import { apiRequest } from "@/lib/queryClient";
import AttendeeForm from "@/components/AttendeeForm";
import { 
  Calendar, 
  Clock, 
  Users, 
  MapPin, 
  User, 
  Share2, 
  ExternalLink,
  Loader2
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";

export default function EventDetails() {
  const { id } = useParams();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Fetch event details
  const { data: event, isLoading } = useQuery<Event>({
    queryKey: [`/api/events/${id}`],
    enabled: !!id,
  });
  
  // Fetch attendees
  const { data: attendees } = useQuery<Attendee[]>({
    queryKey: [`/api/events/${id}/attendees`],
    enabled: !!id,
  });
  
  // Attendee form submission
  const registerMutation = useMutation({
    mutationFn: (formData: Omit<Attendee, "id" | "createdAt" | "eventId">) => {
      return apiRequest("POST", `/api/events/${id}/attendees`, formData);
    },
    onSuccess: () => {
      toast({
        title: "Registration successful",
        description: "You've been registered for this event. Check your email for details.",
        variant: "success",
      });
      // Refresh attendees list
      queryClient.invalidateQueries({ queryKey: [`/api/events/${id}/attendees`] });
    },
    onError: (error: any) => {
      toast({
        title: "Registration failed",
        description: error.message || "There was an error registering for this event. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Share functionality
  const handleShare = async () => {
    const shareData = {
      title: event?.title || "LocalSpot Event",
      text: `Check out this local event: ${event?.title}`,
      url: window.location.href,
    };

    if (navigator.share) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error("Error sharing:", err);
      }
    } else {
      // Fallback - copy to clipboard
      navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied",
        description: "Event link copied to clipboard!",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-12 flex justify-center">
        <Loader2 className="h-12 w-12 animate-spin text-primary/70" />
      </div>
    );
  }

  if (!event) {
    return (
      <div className="container mx-auto px-4 py-12 text-center">
        <h2 className="text-2xl font-bold mb-2">Event not found</h2>
        <p className="mb-6">The event you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate("/")} variant="default">
          Back to Home
        </Button>
      </div>
    );
  }

  // Format date for display
  const eventDate = new Date(event.date);
  const formattedDate = format(eventDate, "EEEE, MMMM d, yyyy");

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="bg-white rounded-lg shadow-xl overflow-hidden">
        <div className="relative h-64 md:h-80 overflow-hidden">
          {/* Default image if none provided */}
          <img 
            src={event.imageUrl || `https://source.unsplash.com/random/1200x500/?${event.category.toLowerCase().replace(/ /g, '-')}`} 
            alt={event.title} 
            className="w-full h-full object-cover" 
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
          
          <div className="absolute bottom-0 left-0 p-6 text-white">
            <Badge variant="secondary" className="mb-2">{event.category}</Badge>
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{event.title}</h1>
            <div className="flex items-center text-white/90 text-sm">
              <MapPin className="h-4 w-4 mr-1" />
              {event.distance !== undefined ? `${event.distance.toFixed(1)} miles away` : 'Location available'}
            </div>
          </div>
          
          <Button 
            variant="ghost" 
            size="icon" 
            className="absolute top-4 right-4 bg-black/40 text-white hover:bg-black/60"
            onClick={() => navigate("/")}
          >
            <ExternalLink className="h-5 w-5" />
          </Button>
        </div>
        
        <div className="p-6 md:p-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <div className="flex flex-wrap gap-y-2 gap-x-6 mb-6">
                <div className="flex items-center text-neutral-700">
                  <Calendar className="h-5 w-5 mr-2 text-primary" />
                  {formattedDate}
                </div>
                <div className="flex items-center text-neutral-700">
                  <Clock className="h-5 w-5 mr-2 text-primary" />
                  {event.time} {event.endTime ? `- ${event.endTime}` : ''}
                </div>
                <div className="flex items-center text-neutral-700">
                  <MapPin className="h-5 w-5 mr-2 text-primary" />
                  {event.location}
                </div>
                <div className="flex items-center text-neutral-700">
                  <Users className="h-5 w-5 mr-2 text-primary" />
                  {attendees?.length || 0} {attendees?.length === 1 ? 'person' : 'people'} attending
                </div>
              </div>
              
              <div className="prose max-w-none">
                <h3 className="text-xl font-semibold mb-2">About this event</h3>
                <p className="whitespace-pre-line">{event.description}</p>
                
                <h3 className="text-xl font-semibold mt-6 mb-2">Location details</h3>
                <p>{event.address}</p>
                
                {/* Map preview */}
                <div className="mt-4 h-64 rounded-lg overflow-hidden">
                  <iframe 
                    width="100%" 
                    height="100%" 
                    frameBorder="0" 
                    style={{ border: 0 }} 
                    src={`https://www.google.com/maps/embed/v1/place?key=AIzaSyBcPYghFh_BXakwCoNLn_hKSuA3Bt5-ypQ&q=${encodeURIComponent(event.address)}`} 
                    allowFullScreen
                  ></iframe>
                </div>
              </div>
              
              <div className="mt-8">
                <h3 className="text-xl font-semibold mb-4">Organizer</h3>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary rounded-full flex items-center justify-center text-white text-xl font-bold">
                    {event.creatorName.charAt(0).toUpperCase()}
                  </div>
                  <div className="ml-4">
                    <div className="font-medium">{event.creatorName}</div>
                    <div className="text-neutral-500 text-sm">Organizer</div>
                  </div>
                </div>
              </div>
              
              <Separator className="my-8" />
              
              <div className="flex flex-wrap gap-4">
                <Button 
                  variant="outline" 
                  className="flex items-center gap-2"
                  onClick={handleShare}
                >
                  <Share2 className="h-4 w-4" />
                  Share Event
                </Button>
              </div>
            </div>
            
            <div>
              <div className="bg-neutral-50 p-5 rounded-lg border border-neutral-200 sticky top-4">
                <h3 className="text-xl font-semibold mb-4">I'm interested!</h3>
                <AttendeeForm 
                  onSubmit={(data) => registerMutation.mutate(data)} 
                  isSubmitting={registerMutation.isPending}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
