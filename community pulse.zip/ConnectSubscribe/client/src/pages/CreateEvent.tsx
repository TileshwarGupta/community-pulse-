import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { InsertEvent } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";
import EventForm from "@/components/EventForm";
import useGeolocation from "@/hooks/useGeolocation";

export default function CreateEvent() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { location } = useGeolocation();
  
  const createEventMutation = useMutation({
    mutationFn: async (eventData: InsertEvent) => {
      const response = await apiRequest("POST", "/api/events", eventData);
      const data = await response.json();
      return data;
    },
    onSuccess: (data) => {
      toast({
        title: "Event created",
        description: "Your event has been created successfully.",
        variant: "success",
      });
      navigate(`/events/${data.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to create event",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  return (
    <section className="bg-neutral-100 py-16">
      <div className="container mx-auto px-4">
        <div className="bg-white rounded-lg shadow-lg overflow-hidden">
          <div className="md:flex">
            <div className="md:w-1/2 p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-4">Create Your Own Event</h2>
              <p className="text-neutral-600 mb-8">
                Share your activities with the community and invite neighbors to join. It's quick and easy!
              </p>
              
              <EventForm 
                onSubmit={(data) => createEventMutation.mutate(data)} 
                isSubmitting={createEventMutation.isPending}
                userLocation={location}
              />
            </div>
            
            <div className="md:w-1/2 bg-primary relative overflow-hidden hidden md:block">
              {/* Background image for event creation page */}
              <img 
                src="https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&h=1200&q=80" 
                alt="Community organizing an event" 
                className="absolute inset-0 w-full h-full object-cover opacity-70" 
              />
              <div className="absolute inset-0 bg-gradient-to-r from-primary/60 to-primary/90"></div>
              <div className="relative z-10 p-12 text-white h-full flex flex-col justify-center">
                <h3 className="text-2xl font-bold mb-4">Why Create a Local Event?</h3>
                <ul className="space-y-4">
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Connect with people who share your interests</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Build a stronger, more connected community</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Promote local businesses and initiatives</span>
                  </li>
                  <li className="flex items-start">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
                    </svg>
                    <span>Create memorable experiences for your neighbors</span>
                  </li>
                </ul>
                <div className="mt-8 bg-white/20 p-4 rounded-lg backdrop-blur-sm">
                  <p className="italic text-white/90">"LocalSpot has transformed our neighborhood. We've organized events that brought together people who've lived on the same street for years but never met!"</p>
                  <p className="font-medium mt-2">- Sarah Johnson, Community Organizer</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
