import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Event } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import EventCard from "@/components/EventCard";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, Search, PlusCircle, CalendarIcon, AlertCircle } from "lucide-react";
import { format } from "date-fns";

export default function MyEvents() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const [creatorEmail, setCreatorEmail] = useState<string>("");
  const [searchSubmitted, setSearchSubmitted] = useState<boolean>(false);
  
  // Fetch events by creator email
  const { 
    data: events, 
    isLoading, 
    isError,
    refetch 
  } = useQuery<Event[]>({
    queryKey: ['/api/events/creator', creatorEmail],
    enabled: !!creatorEmail && searchSubmitted,
  });
  
  // Delete event mutation
  const deleteMutation = useMutation({
    mutationFn: async (eventId: number) => {
      return apiRequest("DELETE", `/api/events/${eventId}`);
    },
    onSuccess: () => {
      toast({
        title: "Event deleted",
        description: "Your event has been deleted successfully.",
        variant: "success",
      });
      // Refetch events list
      refetch();
    },
    onError: (error: any) => {
      toast({
        title: "Failed to delete event",
        description: error.message || "Something went wrong. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchSubmitted(true);
    refetch();
  };

  const handleDelete = (eventId: number) => {
    if (confirm("Are you sure you want to delete this event? This action cannot be undone.")) {
      deleteMutation.mutate(eventId);
    }
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">My Events</h1>
        
        {/* Search by email */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Find Your Events</CardTitle>
            <CardDescription>
              Enter the email address you used when creating events to manage them.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSearch} className="flex gap-2">
              <Input
                type="email"
                placeholder="Your email address"
                value={creatorEmail}
                onChange={(e) => setCreatorEmail(e.target.value)}
                required
                className="flex-1"
              />
              <Button type="submit" disabled={isLoading}>
                {isLoading ? (
                  <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                Search
              </Button>
            </form>
          </CardContent>
        </Card>
        
        {/* Create event button */}
        <div className="mb-8">
          <Button onClick={() => navigate("/create")} className="flex items-center gap-2">
            <PlusCircle className="h-5 w-5" />
            Create New Event
          </Button>
        </div>
        
        {/* Events list */}
        {isLoading ? (
          <div className="flex justify-center my-12">
            <Loader2 className="h-12 w-12 animate-spin text-primary/70" />
          </div>
        ) : isError ? (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Error</AlertTitle>
            <AlertDescription>
              Failed to load your events. Please try again.
            </AlertDescription>
          </Alert>
        ) : events && searchSubmitted ? (
          events.length > 0 ? (
            <div className="space-y-6">
              {events.map((event) => (
                <Card key={event.id} className="overflow-hidden">
                  <div className="md:flex">
                    <div className="md:w-1/4 bg-neutral-100 flex items-center justify-center p-6">
                      <div className="text-center">
                        <CalendarIcon className="h-10 w-10 text-primary mx-auto mb-2" />
                        <div className="text-sm text-neutral-500">
                          {format(new Date(event.date), "MMM d, yyyy")}
                        </div>
                        <div className="font-medium">{event.time}</div>
                      </div>
                    </div>
                    <div className="md:w-3/4 p-6">
                      <h3 className="text-xl font-bold mb-2">{event.title}</h3>
                      <div className="flex items-center text-sm text-neutral-500 mb-2">
                        <CalendarIcon className="h-4 w-4 mr-1" />
                        {format(new Date(event.date), "EEEE, MMMM d, yyyy")} at {event.time}
                      </div>
                      <p className="text-neutral-600 mb-4 line-clamp-2">{event.description}</p>
                      <div className="flex flex-wrap gap-2">
                        <Button 
                          variant="default" 
                          onClick={() => navigate(`/events/${event.id}`)}
                        >
                          View Details
                        </Button>
                        <Button 
                          variant="destructive"
                          onClick={() => handleDelete(event.id)}
                        >
                          Delete Event
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <Card>
              <CardContent className="pt-6 pb-6 text-center">
                <div className="mb-4">
                  <CalendarIcon className="h-12 w-12 text-neutral-300 mx-auto" />
                </div>
                <h3 className="text-xl font-medium mb-2">No events found</h3>
                <p className="text-neutral-600 mb-4">
                  We couldn't find any events created with this email address.
                </p>
                <Button onClick={() => navigate("/create")}>Create Your First Event</Button>
              </CardContent>
            </Card>
          )
        ) : null}
      </div>
    </div>
  );
}
