import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Event } from "@shared/schema";
import Hero from "@/components/Hero";
import CategoryCard from "@/components/CategoryCard";
import MapView from "@/components/MapView";
import EventCard from "@/components/EventCard";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MapIcon, ListIcon, Loader2 } from "lucide-react";
import useGeolocation from "@/hooks/useGeolocation";

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<"map" | "list">("map");
  const [, navigate] = useLocation();
  const { location } = useGeolocation();

  // Fetch all events
  const { data: events, isLoading } = useQuery<Event[]>({
    queryKey: ['/api/events'],
  });

  // Fetch categories
  const { data: categories } = useQuery<string[]>({
    queryKey: ['/api/categories'],
  });

  // Filter events by category if selected
  const filteredEvents = selectedCategory
    ? events?.filter(event => event.category === selectedCategory)
    : events;

  // Calculate distance from user's location to each event
  const eventsWithDistance = filteredEvents?.map(event => {
    let distance = 0;
    
    if (location.latitude && location.longitude) {
      // Simple distance calculation (not accurate for long distances but good enough for this demo)
      const eventLat = parseFloat(event.latitude);
      const eventLng = parseFloat(event.longitude);
      const lat1 = location.latitude;
      const lon1 = location.longitude;
      
      const R = 6371; // Radius of the earth in km
      const dLat = deg2rad(eventLat - lat1);
      const dLon = deg2rad(eventLng - lon1);
      const a = 
        Math.sin(dLat/2) * Math.sin(dLat/2) +
        Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(eventLat)) * 
        Math.sin(dLon/2) * Math.sin(dLon/2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
      distance = R * c; // Distance in km
    }
    
    return {
      ...event,
      distance
    };
  }).sort((a, b) => a.distance - b.distance);

  // Helper function for distance calculation
  function deg2rad(deg: number) {
    return deg * (Math.PI/180);
  }

  return (
    <div className="min-h-screen">
      <Hero />
      
      {/* Categories Section */}
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold mb-8 text-center">Explore by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {categories?.map((category) => (
            <CategoryCard 
              key={category} 
              category={category} 
              isSelected={selectedCategory === category}
              onClick={() => setSelectedCategory(category === selectedCategory ? null : category)}
            />
          ))}
        </div>
      </section>
      
      {/* Events Section */}
      <section id="explore" className="container mx-auto px-4 py-12">
        <div className="flex flex-col md:flex-row justify-between items-start mb-8">
          <div>
            <h2 className="text-3xl font-bold">Events Near You</h2>
            <p className="text-neutral-600 mt-2">
              {selectedCategory 
                ? `Showing ${selectedCategory} events near you`
                : "Discover activities happening around your area"}
            </p>
          </div>
          <div className="flex mt-4 md:mt-0">
            <Button
              variant={viewMode === "list" ? "default" : "outline"}
              className="rounded-l-md rounded-r-none px-4"
              onClick={() => setViewMode("list")}
            >
              <ListIcon className="h-5 w-5 mr-2" />
              List
            </Button>
            <Button
              variant={viewMode === "map" ? "default" : "outline"}
              className="rounded-r-md rounded-l-none px-4"
              onClick={() => setViewMode("map")}
            >
              <MapIcon className="h-5 w-5 mr-2" />
              Map
            </Button>
          </div>
        </div>
        
        <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "map" | "list")}>
          <TabsContent value="map" className="mt-0">
            <div className="bg-white rounded-lg shadow-md overflow-hidden mb-8 h-96 relative">
              {isLoading ? (
                <div className="absolute inset-0 flex items-center justify-center">
                  <Loader2 className="h-12 w-12 animate-spin text-primary/70" />
                </div>
              ) : (
                <MapView 
                  events={eventsWithDistance || []} 
                  userLocation={location}
                  onMarkerClick={(eventId) => navigate(`/events/${eventId}`)}
                />
              )}
            </div>
          </TabsContent>
          
          <TabsContent value="list" className="mt-0">
            {isLoading ? (
              <div className="flex justify-center my-12">
                <Loader2 className="h-12 w-12 animate-spin text-primary/70" />
              </div>
            ) : eventsWithDistance && eventsWithDistance.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {eventsWithDistance.map((event) => (
                  <EventCard key={event.id} event={event} />
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <h3 className="text-xl font-medium mb-2">No events found</h3>
                <p className="text-neutral-600 mb-4">
                  {selectedCategory 
                    ? `There are no ${selectedCategory} events scheduled at the moment.`
                    : "There are no events scheduled at the moment."}
                </p>
                <Button onClick={() => navigate("/create")}>Create an Event</Button>
              </div>
            )}
          </TabsContent>
        </Tabs>
        
        {eventsWithDistance && eventsWithDistance.length > 6 && (
          <div className="mt-8 text-center">
            <Button variant="outline" className="border-primary text-primary hover:bg-primary/5">
              Load More Events
            </Button>
          </div>
        )}
      </section>
      
      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h2 className="text-3xl font-bold mb-12 text-center">How LocalSpot Makes Community Events Better</h2>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center">
            <div className="bg-primary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <MapIcon className="h-8 w-8 text-primary" />
            </div>
            <h3 className="text-xl font-bold mb-2">Discover Nearby</h3>
            <p className="text-neutral-600">Find events happening right in your neighborhood, sorted by distance and relevance to your interests.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-secondary/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-secondary" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Stay Updated</h3>
            <p className="text-neutral-600">Receive timely notifications about event changes, reminders, and updates via your preferred method.</p>
          </div>
          
          <div className="text-center">
            <div className="bg-accent/10 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-accent" viewBox="0 0 20 20" fill="currentColor">
                <path d="M13 6a3 3 0 11-6 0 3 3 0 016 0zM18 8a2 2 0 11-4 0 2 2 0 014 0zM14 15a4 4 0 00-8 0v3h8v-3zM6 8a2 2 0 11-4 0 2 2 0 014 0zM16 18v-3a5.972 5.972 0 00-.75-2.906A3.005 3.005 0 0119 15v3h-3zM4.75 12.094A5.973 5.973 0 004 15v3H1v-3a3 3 0 013.75-2.906z" />
              </svg>
            </div>
            <h3 className="text-xl font-bold mb-2">Easy RSVP</h3>
            <p className="text-neutral-600">No lengthy sign-up forms. Just share basic info to show your interest in attending local events.</p>
          </div>
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="bg-primary text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4">Ready to Discover Your Neighborhood?</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">Join LocalSpot today and connect with events, activities, and neighbors in your community.</p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button 
              variant="secondary" 
              size="lg"
              onClick={() => navigate("/create")}
            >
              Create an Event
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              className="bg-transparent border-2 border-white hover:bg-white/10"
              onClick={() => {
                const exploreSection = document.getElementById("explore");
                if (exploreSection) {
                  exploreSection.scrollIntoView({ behavior: "smooth" });
                }
              }}
            >
              Explore Events
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}
