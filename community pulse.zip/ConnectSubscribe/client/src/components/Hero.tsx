import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MapPin, Search } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { EVENT_CATEGORIES } from "@shared/schema";
import useGeolocation from "@/hooks/useGeolocation";

export default function Hero() {
  const [, navigate] = useLocation();
  const [category, setCategory] = useState<string>("");
  const [location, setLocation] = useState<string>("");
  const { location: userLocation, requestLocation } = useGeolocation();
  
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const exploreSection = document.getElementById("explore");
    if (exploreSection) {
      exploreSection.scrollIntoView({ behavior: "smooth" });
    }
  };
  
  return (
    <section className="relative overflow-hidden bg-primary text-white">
      {/* Background image with overlay */}
      <div 
        className="absolute inset-0 z-0 bg-cover bg-center opacity-20" 
        style={{ 
          backgroundImage: "url('https://images.unsplash.com/photo-1511632765486-a01980e01a18?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80')"
        }}
      ></div>
      
      <div className="container mx-auto px-4 py-16 md:py-24 relative z-10">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">Discover What's Happening Near You</h1>
          <p className="text-xl mb-8">Join local events, connect with your community, and make meaningful connections in your neighborhood.</p>
          
          <Card className="bg-white rounded-lg shadow-lg overflow-hidden">
            <CardContent className="p-0">
              <form onSubmit={handleSearch} className="flex flex-col md:flex-row">
                <div className="flex-grow p-4 border-b md:border-b-0 md:border-r border-neutral-200">
                  <label htmlFor="location" className="block text-neutral-500 text-sm mb-1">Location</label>
                  <div className="relative">
                    <Input
                      id="location"
                      type="text"
                      placeholder="Your neighborhood"
                      className="border-none p-0 shadow-none focus-visible:ring-0 text-neutral-800"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      className="absolute right-0 top-0 px-2 text-neutral-400 hover:text-primary"
                      onClick={requestLocation}
                    >
                      <MapPin className="h-5 w-5" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex-grow p-4 border-b md:border-b-0 md:border-r border-neutral-200">
                  <label htmlFor="category" className="block text-neutral-500 text-sm mb-1">Category</label>
                  <Select
                    value={category}
                    onValueChange={setCategory}
                  >
                    <SelectTrigger 
                      id="category"
                      className="border-none p-0 shadow-none focus:ring-0 text-neutral-800"
                    >
                      <SelectValue placeholder="All Categories" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Categories</SelectItem>
                      {EVENT_CATEGORIES.map((cat) => (
                        <SelectItem key={cat} value={cat}>
                          {cat}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <Button
                  type="submit"
                  className="bg-accent text-white hover:bg-amber-500 m-4 ml-auto"
                >
                  <Search className="h-5 w-5 mr-2" />
                  Find Events
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}
