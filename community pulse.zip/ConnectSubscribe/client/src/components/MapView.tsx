import { useEffect, useState } from "react";
import L from "leaflet";
import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Event } from "@shared/schema";
import { Button } from "@/components/ui/button";
import "leaflet/dist/leaflet.css";

// Fix Leaflet marker icon issue in React
import icon from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

let DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41],
});

L.Marker.prototype.options.icon = DefaultIcon;

// Custom marker icons for different categories
const createCategoryIcon = (className: string) => {
  return L.divIcon({
    className: `custom-marker ${className}`,
    html: `
      <div class="w-6 h-6 ${className} rounded-full flex items-center justify-center animate-pulse">
        <div class="w-4 h-4 bg-white rounded-full"></div>
      </div>
    `,
    iconSize: [24, 24],
    iconAnchor: [12, 12],
  });
};

// Component to recenter map when user location changes
function RecenterMap({ lat, lng }: { lat: number; lng: number }) {
  const map = useMap();
  
  useEffect(() => {
    if (lat && lng) {
      map.setView([lat, lng], 13);
    }
  }, [lat, lng, map]);
  
  return null;
}

interface MapViewProps {
  events: (Event & { distance?: number })[];
  userLocation: { latitude: number | null; longitude: number | null };
  onMarkerClick?: (eventId: number) => void;
}

export default function MapView({ events, userLocation, onMarkerClick }: MapViewProps) {
  const [map, setMap] = useState<L.Map | null>(null);

  // Get category-based marker icon
  const getCategoryIcon = (category: string) => {
    const slug = category.toLowerCase().replace(/\s+/g, "-").replace(/[&]/g, "").replace(/[^a-z0-9-]/g, "");
    return createCategoryIcon(`pin-${slug}`);
  };

  // Set default center to user location or first event or fallback
  const defaultCenter: [number, number] = 
    (userLocation.latitude && userLocation.longitude) 
      ? [userLocation.latitude, userLocation.longitude] 
      : events.length > 0 && events[0].latitude && events[0].longitude
        ? [parseFloat(events[0].latitude), parseFloat(events[0].longitude)]
        : [40.7128, -74.0060]; // Default to NYC

  return (
    <MapContainer 
      center={defaultCenter} 
      zoom={13} 
      style={{ height: "100%", width: "100%" }}
      whenCreated={setMap}
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      
      {/* User location marker */}
      {userLocation.latitude && userLocation.longitude && (
        <Marker 
          position={[userLocation.latitude, userLocation.longitude]}
          icon={L.divIcon({
            className: 'custom-marker',
            html: `
              <div class="w-6 h-6 bg-blue-500 border-2 border-white rounded-full flex items-center justify-center">
                <div class="w-2 h-2 bg-white rounded-full"></div>
              </div>
            `,
            iconSize: [24, 24],
            iconAnchor: [12, 12],
          })}
        >
          <Popup>
            <div className="text-center">
              <strong>Your Location</strong>
            </div>
          </Popup>
        </Marker>
      )}
      
      {/* Event markers */}
      {events.map(event => {
        const lat = parseFloat(event.latitude);
        const lng = parseFloat(event.longitude);
        
        if (isNaN(lat) || isNaN(lng)) return null;
        
        return (
          <Marker 
            key={event.id} 
            position={[lat, lng]}
            icon={getCategoryIcon(event.category)}
          >
            <Popup>
              <div className="text-center py-1">
                <h3 className="font-semibold text-lg">{event.title}</h3>
                <p className="text-sm mb-2">{event.category}</p>
                <p className="text-xs mb-2 text-neutral-500">
                  {new Date(event.date).toLocaleDateString()} at {event.time}
                </p>
                {onMarkerClick && (
                  <Button 
                    size="sm" 
                    onClick={() => onMarkerClick(event.id)}
                    className="w-full mt-1"
                  >
                    View Details
                  </Button>
                )}
              </div>
            </Popup>
          </Marker>
        );
      })}
      
      {/* Recenter map when user location changes */}
      {userLocation.latitude && userLocation.longitude && (
        <RecenterMap lat={userLocation.latitude} lng={userLocation.longitude} />
      )}
    </MapContainer>
  );
}
