import { Link } from "wouter";
import { format } from "date-fns";
import { Event } from "@shared/schema";
import { Calendar, Clock, MapPin } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

interface EventCardProps {
  event: Event & { distance?: number };
}

export default function EventCard({ event }: EventCardProps) {
  // Get category slug for styling
  const getCategorySlug = (category: string) => {
    return category.toLowerCase().replace(/\s+/g, "-").replace(/[&]/g, "").replace(/[^a-z0-9-]/g, "");
  };
  
  // Format date
  const formattedDate = format(new Date(event.date), "EEE, MMM d");
  
  // Get creator initials for avatar
  const getInitials = (name: string) => {
    return name
      .split(' ')
      .map(part => part.charAt(0).toUpperCase())
      .join('')
      .substring(0, 2);
  };
  
  // Get category badge colors
  const getCategoryColor = (category: string) => {
    const slug = getCategorySlug(category);
    switch(slug) {
      case "garage-sales":
        return "bg-primary/10 text-primary";
      case "sports-matches":
        return "bg-secondary/10 text-secondary";
      case "community-classes":
        return "bg-accent/10 text-accent";
      case "volunteer-opportunities":
        return "bg-red-100 text-red-500";
      case "exhibitions":
        return "bg-purple-100 text-purple-500";
      case "festivals-celebrations":
        return "bg-pink-100 text-pink-500";
      default:
        return "bg-neutral-100 text-neutral-700";
    }
  };

  return (
    <Card className="overflow-hidden h-full flex flex-col">
      {/* Event image */}
      <div className="h-40 overflow-hidden">
        <img 
          src={event.imageUrl || `https://source.unsplash.com/random/800x500/?${getCategorySlug(event.category)}`} 
          alt={event.title} 
          className="w-full h-full object-cover transition-transform hover:scale-105 duration-300" 
        />
      </div>
      
      <CardContent className="p-4 flex-1 flex flex-col">
        <div className="flex justify-between items-start">
          <Badge variant="outline" className={`${getCategoryColor(event.category)} px-2 py-1 rounded text-xs font-medium`}>
            {event.category}
          </Badge>
          {event.distance !== undefined && (
            <span className="text-neutral-500 text-sm">{event.distance.toFixed(1)} miles away</span>
          )}
        </div>
        
        <h3 className="font-bold text-lg mt-2">{event.title}</h3>
        
        <p className="text-neutral-600 text-sm mt-1 mb-3 line-clamp-2 flex-grow">
          {event.description}
        </p>
        
        <div className="flex items-center text-sm text-neutral-500 mb-3">
          <Calendar className="h-4 w-4 mr-1" />
          {formattedDate}
          <Clock className="h-4 w-4 ml-3 mr-1" />
          {event.time}
        </div>
        
        <div className="flex items-center text-sm text-neutral-500 mb-4">
          <MapPin className="h-4 w-4 mr-1 flex-shrink-0" />
          <span className="truncate">{event.location}</span>
        </div>
        
        <div className="border-t border-neutral-200 pt-4 flex justify-between">
          <div className="flex items-center">
            <Avatar className="h-8 w-8 bg-primary">
              <AvatarFallback>{getInitials(event.creatorName)}</AvatarFallback>
            </Avatar>
            <span className="text-sm font-medium ml-2 truncate max-w-[100px]">{event.creatorName}</span>
          </div>
          <Link href={`/events/${event.id}`} className="text-primary font-medium text-sm hover:underline">
            View Details
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
