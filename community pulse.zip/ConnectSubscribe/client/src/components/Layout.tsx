import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  Menu, 
  X, 
  Home, 
  MapPin, 
  PlusCircle, 
  Calendar,
  User
} from "lucide-react";
import { 
  Sheet, 
  SheetContent, 
  SheetDescription, 
  SheetHeader, 
  SheetTitle, 
  SheetTrigger 
} from "@/components/ui/sheet";

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const [location] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Navigation links
  const navLinks = [
    { href: "/", label: "Home", icon: <Home className="h-5 w-5" /> },
    { href: "/#explore", label: "Explore", icon: <MapPin className="h-5 w-5" /> },
    { href: "/create", label: "Create Event", icon: <PlusCircle className="h-5 w-5" /> },
    { href: "/my-events", label: "My Events", icon: <Calendar className="h-5 w-5" /> },
  ];
  
  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/" className="text-2xl font-bold text-primary flex items-center">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mr-2" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
            </svg>
            LocalSpot
          </Link>
          
          {/* Desktop Navigation */}
          <div className="md:flex items-center hidden">
            {navLinks.map((link) => (
              <Link 
                key={link.href} 
                href={link.href}
                className={`mx-3 font-medium ${
                  location === link.href 
                    ? "text-primary" 
                    : "text-neutral-700 hover:text-primary"
                } transition-colors`}
              >
                {link.label}
              </Link>
            ))}
            {/* No sign-in button needed for our implementation */}
          </div>
          
          {/* Mobile Navigation Trigger */}
          <Sheet open={mobileMenuOpen} onOpenChange={setMobileMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-64">
              <SheetHeader className="mb-4">
                <SheetTitle className="text-primary flex items-center">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                  </svg>
                  LocalSpot
                </SheetTitle>
                <SheetDescription>
                  Connect with your community
                </SheetDescription>
              </SheetHeader>
              <nav className="flex flex-col gap-2">
                {navLinks.map((link) => (
                  <Link 
                    key={link.href} 
                    href={link.href}
                    onClick={() => setMobileMenuOpen(false)}
                    className={`flex items-center gap-3 p-2 rounded-md ${
                      location === link.href 
                        ? "bg-primary/10 text-primary" 
                        : "hover:bg-neutral-100"
                    } transition-colors`}
                  >
                    {link.icon}
                    {link.label}
                  </Link>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </header>
      
      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>
      
      {/* Footer */}
      <footer className="bg-neutral-800 text-white pt-12 pb-6">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
            <div>
              <h3 className="text-xl font-bold mb-4 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                LocalSpot
              </h3>
              <p className="text-neutral-400 mb-4">Connecting communities through local events and activities.</p>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Explore</h3>
              <ul className="space-y-2">
                <li><Link href="/#explore" className="text-neutral-400 hover:text-white transition-colors">All Events</Link></li>
                <li><Link href="/" className="text-neutral-400 hover:text-white transition-colors">Categories</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">Organize</h3>
              <ul className="space-y-2">
                <li><Link href="/create" className="text-neutral-400 hover:text-white transition-colors">Create Event</Link></li>
                <li><Link href="/my-events" className="text-neutral-400 hover:text-white transition-colors">Manage Events</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4">About</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Our Mission</a></li>
                <li><a href="#" className="text-neutral-400 hover:text-white transition-colors">Community Guidelines</a></li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 mt-8 border-t border-neutral-700 text-neutral-400 text-sm flex flex-col md:flex-row justify-between items-center">
            <p>&copy; {new Date().getFullYear()} LocalSpot. All rights reserved.</p>
            <div className="mt-4 md:mt-0">
              <a href="#" className="mr-4 hover:text-white transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-white transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
      
      {/* Mobile Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white shadow-up-lg border-t border-neutral-200 z-40">
        <div className="flex justify-around">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={`flex flex-col items-center py-2 px-4 ${
                location === link.href ? "text-primary" : "text-neutral-400"
              }`}
            >
              {link.icon}
              <span className="text-xs mt-1">{link.label.split(' ')[0]}</span>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}
