import { Event } from "@shared/schema";

// Helper functions for working with events

// Calculate distance between two coordinates in kilometers
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Radius of the earth in km
  const dLat = deg2rad(lat2 - lat1);
  const dLon = deg2rad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  const d = R * c; // Distance in km
  return d;
}

// Convert degrees to radians
function deg2rad(deg: number): number {
  return deg * (Math.PI / 180);
}

// Get appropriate image URL for an event category
export function getCategoryImageUrl(category: string): string {
  const slug = category.toLowerCase().replace(/\s+/g, '-').replace(/[&]/g, '').replace(/[^a-z0-9-]/g, '');
  return `https://source.unsplash.com/random/800x500/?${slug}`;
}

// Format event distance for display
export function formatDistance(distance: number): string {
  if (distance < 0.1) {
    return "Very close";
  } else if (distance < 1) {
    return `${(distance * 1000).toFixed(0)} meters away`;
  } else {
    return `${distance.toFixed(1)} km away`;
  }
}

// Get events sorted by proximity to a location
export function getEventsByProximity(
  events: Event[],
  latitude: number,
  longitude: number
): (Event & { distance: number })[] {
  return events
    .map(event => {
      const eventLat = parseFloat(event.latitude);
      const eventLng = parseFloat(event.longitude);
      const distance = calculateDistance(latitude, longitude, eventLat, eventLng);
      return { ...event, distance };
    })
    .sort((a, b) => a.distance - b.distance);
}

// Filter events by category
export function filterEventsByCategory(events: Event[], category: string | null): Event[] {
  if (!category) return events;
  return events.filter(event => event.category === category);
}

// Get upcoming events (ignore past events)
export function getUpcomingEvents(events: Event[]): Event[] {
  const now = new Date();
  return events.filter(event => new Date(event.date) >= now);
}
