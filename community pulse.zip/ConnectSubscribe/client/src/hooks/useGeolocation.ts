import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";

interface Location {
  latitude: number | null;
  longitude: number | null;
  error: string | null;
}

export default function useGeolocation() {
  const [location, setLocation] = useState<Location>({
    latitude: null,
    longitude: null,
    error: null,
  });
  const [isRequesting, setIsRequesting] = useState(false);
  const { toast } = useToast();

  // Get user's location on initial render
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.permissions.query({ name: "geolocation" }).then((result) => {
        if (result.state === "granted") {
          requestLocation();
        }
      });
    }
  }, []);

  const requestLocation = () => {
    if (!navigator.geolocation) {
      setLocation((prev) => ({
        ...prev,
        error: "Geolocation is not supported by your browser",
      }));
      
      toast({
        title: "Location Error",
        description: "Geolocation is not supported by your browser",
        variant: "destructive",
      });
      
      return;
    }

    setIsRequesting(true);
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setLocation({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          error: null,
        });
        setIsRequesting(false);
        
        toast({
          title: "Location Found",
          description: "Using your current location for nearby events",
        });
      },
      (error) => {
        setLocation((prev) => ({
          ...prev,
          error: error.message,
        }));
        setIsRequesting(false);
        
        toast({
          title: "Location Error",
          description: error.message,
          variant: "destructive",
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      }
    );
  };

  return {
    location,
    isRequesting,
    requestLocation,
  };
}
