import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import nodemailer from "nodemailer";
import { formatDistanceToNow, addDays, isBefore, isAfter } from "date-fns";
import { 
  insertEventSchema, 
  insertAttendeeSchema,
  EVENT_CATEGORIES
} from "@shared/schema";
import { z } from "zod";
import { ZodError } from "zod-validation-error";

// Create a test account for nodemailer (for development)
const createTestAccount = async () => {
  return await nodemailer.createTestAccount();
};

// Set up nodemailer transporter
let transporter: nodemailer.Transporter;

const initializeTransporter = async () => {
  try {
    const testAccount = await createTestAccount();
    
    transporter = nodemailer.createTransport({
      host: "smtp.ethereal.email",
      port: 587,
      secure: false,
      auth: {
        user: testAccount.user,
        pass: testAccount.pass,
      },
    });
    
    console.log("Email transporter initialized");
  } catch (error) {
    console.error("Failed to initialize email transporter:", error);
  }
};

// Schedule notifications for events (will run every minute)
const scheduleNotifications = () => {
  setInterval(async () => {
    try {
      const events = await storage.getEvents();
      const now = new Date();
      
      for (const event of events) {
        const eventDate = new Date(event.date);
        const oneDayBefore = addDays(eventDate, -1);
        
        // Check if it's time to send reminder (1 day before the event)
        if (
          event.sendNotifications && 
          isBefore(oneDayBefore, now) && 
          isAfter(eventDate, now)
        ) {
          const attendees = await storage.getAttendees(event.id);
          
          for (const attendee of attendees) {
            if (attendee.notificationsEnabled) {
              // Check if we've already sent a reminder to this attendee
              const notifications = await storage.getNotifications(event.id);
              const hasReminder = notifications.some(
                (n) => n.attendeeId === attendee.id && n.type === "reminder"
              );
              
              if (!hasReminder) {
                // Send email reminder
                await sendEmail(
                  attendee.email,
                  `Reminder: ${event.title} is tomorrow!`,
                  `
                  <h2>Event Reminder</h2>
                  <p>Hello ${attendee.name},</p>
                  <p>This is a reminder that <strong>${event.title}</strong> is happening tomorrow at ${event.time}.</p>
                  <p>Location: ${event.location}, ${event.address}</p>
                  <p>We look forward to seeing you there!</p>
                  <p>If you can no longer attend, please let the organizer know.</p>
                  `
                );
                
                // Record that we sent a notification
                await storage.createNotification({
                  eventId: event.id,
                  attendeeId: attendee.id,
                  type: "reminder"
                });
              }
            }
          }
        }
      }
    } catch (error) {
      console.error("Error in notification scheduler:", error);
    }
  }, 60000); // Check every minute
};

// Helper function to send emails
const sendEmail = async (to: string, subject: string, html: string) => {
  try {
    if (!transporter) {
      console.log("Email transporter not initialized");
      return;
    }
    
    const info = await transporter.sendMail({
      from: '"LocalSpot" <notifications@localspot.example.com>',
      to,
      subject,
      html,
    });
    
    console.log("Email sent:", info.messageId);
    console.log("Preview URL:", nodemailer.getTestMessageUrl(info));
    
    return info;
  } catch (error) {
    console.error("Failed to send email:", error);
    throw error;
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Initialize the email transporter
  await initializeTransporter();
  
  // Start the notification scheduler
  scheduleNotifications();
  
  // === Events API ===
  
  // Get all events
  app.get("/api/events", async (req: Request, res: Response) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      console.error("Error fetching events:", error);
      res.status(500).json({ message: "Failed to fetch events" });
    }
  });
  
  // Get events by category
  app.get("/api/events/category/:category", async (req: Request, res: Response) => {
    try {
      const { category } = req.params;
      const events = await storage.getEventsByCategory(category);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events by category:", error);
      res.status(500).json({ message: "Failed to fetch events by category" });
    }
  });
  
  // Get events by creator
  app.get("/api/events/creator/:email", async (req: Request, res: Response) => {
    try {
      const { email } = req.params;
      const events = await storage.getEventsByCreator(email);
      res.json(events);
    } catch (error) {
      console.error("Error fetching events by creator:", error);
      res.status(500).json({ message: "Failed to fetch events by creator" });
    }
  });
  
  // Get single event
  app.get("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const event = await storage.getEvent(id);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.json(event);
    } catch (error) {
      console.error("Error fetching event:", error);
      res.status(500).json({ message: "Failed to fetch event" });
    }
  });
  
  // Create event
  app.post("/api/events", async (req: Request, res: Response) => {
    try {
      const eventData = insertEventSchema.parse(req.body);
      const event = await storage.createEvent(eventData);
      res.status(201).json(event);
    } catch (error) {
      console.error("Error creating event:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid event data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to create event" });
    }
  });
  
  // Update event
  app.put("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      const eventData = req.body;
      
      const existingEvent = await storage.getEvent(id);
      if (!existingEvent) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      const updatedEvent = await storage.updateEvent(id, eventData);
      
      // If the event details changed, notify attendees
      if (
        existingEvent.date !== eventData.date || 
        existingEvent.time !== eventData.time ||
        existingEvent.location !== eventData.location ||
        existingEvent.address !== eventData.address
      ) {
        const attendees = await storage.getAttendees(id);
        
        for (const attendee of attendees) {
          if (attendee.notificationsEnabled) {
            // Send email notification about the update
            await sendEmail(
              attendee.email,
              `Update: Changes to event "${existingEvent.title}"`,
              `
              <h2>Event Update</h2>
              <p>Hello ${attendee.name},</p>
              <p>The details for <strong>${existingEvent.title}</strong> have been updated:</p>
              <ul>
                ${existingEvent.date !== eventData.date ? `<li>New date: ${new Date(eventData.date).toLocaleDateString()}</li>` : ''}
                ${existingEvent.time !== eventData.time ? `<li>New time: ${eventData.time}</li>` : ''}
                ${existingEvent.location !== eventData.location ? `<li>New location: ${eventData.location}</li>` : ''}
                ${existingEvent.address !== eventData.address ? `<li>New address: ${eventData.address}</li>` : ''}
              </ul>
              <p>We look forward to seeing you there!</p>
              `
            );
            
            // Record that we sent a notification
            await storage.createNotification({
              eventId: id,
              attendeeId: attendee.id,
              type: "update"
            });
          }
        }
      }
      
      res.json(updatedEvent);
    } catch (error) {
      console.error("Error updating event:", error);
      res.status(500).json({ message: "Failed to update event" });
    }
  });
  
  // Delete event
  app.delete("/api/events/:id", async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      
      const event = await storage.getEvent(id);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Notify attendees about cancellation
      const attendees = await storage.getAttendees(id);
      for (const attendee of attendees) {
        if (attendee.notificationsEnabled) {
          // Send email notification about the cancellation
          await sendEmail(
            attendee.email,
            `CANCELLED: ${event.title}`,
            `
            <h2>Event Cancellation</h2>
            <p>Hello ${attendee.name},</p>
            <p>We regret to inform you that <strong>${event.title}</strong> scheduled for ${new Date(event.date).toLocaleDateString()} at ${event.time} has been cancelled.</p>
            <p>For any questions, please contact the organizer directly.</p>
            `
          );
          
          // Record that we sent a notification
          await storage.createNotification({
            eventId: id,
            attendeeId: attendee.id,
            type: "cancellation"
          });
        }
      }
      
      const success = await storage.deleteEvent(id);
      
      if (!success) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      res.status(204).end();
    } catch (error) {
      console.error("Error deleting event:", error);
      res.status(500).json({ message: "Failed to delete event" });
    }
  });
  
  // === Attendees API ===
  
  // Get attendees for an event
  app.get("/api/events/:eventId/attendees", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.eventId);
      const attendees = await storage.getAttendees(eventId);
      res.json(attendees);
    } catch (error) {
      console.error("Error fetching attendees:", error);
      res.status(500).json({ message: "Failed to fetch attendees" });
    }
  });
  
  // Register as attendee
  app.post("/api/events/:eventId/attendees", async (req: Request, res: Response) => {
    try {
      const eventId = parseInt(req.params.eventId);
      
      // Check if event exists
      const event = await storage.getEvent(eventId);
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Validate attendee data
      const attendeeData = insertAttendeeSchema.parse({
        ...req.body,
        eventId
      });
      
      // Check if attendee with this email already registered for this event
      const existingAttendee = await storage.getAttendeeByEmailAndEvent(
        attendeeData.email,
        eventId
      );
      
      if (existingAttendee) {
        return res.status(400).json({ 
          message: "You are already registered for this event" 
        });
      }
      
      // Create the attendee
      const attendee = await storage.createAttendee(attendeeData);
      
      // Send confirmation email
      await sendEmail(
        attendee.email,
        `Registration Confirmation: ${event.title}`,
        `
        <h2>Registration Confirmed</h2>
        <p>Hello ${attendee.name},</p>
        <p>Thank you for registering for <strong>${event.title}</strong>!</p>
        <p>
          <strong>Date:</strong> ${new Date(event.date).toLocaleDateString()}<br>
          <strong>Time:</strong> ${event.time}<br>
          <strong>Location:</strong> ${event.location}, ${event.address}
        </p>
        <p>You registered with ${attendee.numberOfGuests} guest${attendee.numberOfGuests !== 1 ? 's' : ''}.</p>
        <p>We look forward to seeing you there!</p>
        `
      );
      
      res.status(201).json(attendee);
    } catch (error) {
      console.error("Error registering attendee:", error);
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Invalid attendee data", 
          errors: error.errors 
        });
      }
      res.status(500).json({ message: "Failed to register for the event" });
    }
  });
  
  // Get list of categories
  app.get("/api/categories", (req: Request, res: Response) => {
    res.json(EVENT_CATEGORIES);
  });

  const httpServer = createServer(app);
  return httpServer;
}
