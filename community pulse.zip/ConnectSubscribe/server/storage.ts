import { 
  events, 
  type Event, 
  type InsertEvent, 
  attendees, 
  type Attendee, 
  type InsertAttendee,
  notifications,
  type Notification,
  type InsertNotification,
  users, 
  type User, 
  type InsertUser 
} from "@shared/schema";

// modify the interface with any CRUD methods
// you might need
export interface IStorage {
  // Users (keeping existing methods)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Events
  getEvents(): Promise<Event[]>;
  getEventsByCategory(category: string): Promise<Event[]>;
  getEventsByCreator(creatorEmail: string): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<boolean>;

  // Attendees
  getAttendees(eventId: number): Promise<Attendee[]>;
  getAttendee(id: number): Promise<Attendee | undefined>;
  getAttendeeByEmailAndEvent(email: string, eventId: number): Promise<Attendee | undefined>;
  createAttendee(attendee: InsertAttendee): Promise<Attendee>;
  updateAttendee(id: number, attendee: Partial<InsertAttendee>): Promise<Attendee | undefined>;
  deleteAttendee(id: number): Promise<boolean>;

  // Notifications
  getNotifications(eventId: number): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private events: Map<number, Event>;
  private attendees: Map<number, Attendee>;
  private notifications: Map<number, Notification>;
  private currentUserId: number;
  private currentEventId: number;
  private currentAttendeeId: number;
  private currentNotificationId: number;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    this.attendees = new Map();
    this.notifications = new Map();
    this.currentUserId = 1;
    this.currentEventId = 1;
    this.currentAttendeeId = 1;
    this.currentNotificationId = 1;
  }

  // User methods (keeping existing methods)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Event methods
  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async getEventsByCategory(category: string): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.category === category
    );
  }

  async getEventsByCreator(creatorEmail: string): Promise<Event[]> {
    return Array.from(this.events.values()).filter(
      (event) => event.creatorEmail === creatorEmail
    );
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.currentEventId++;
    const createdAt = new Date();
    const event: Event = { ...insertEvent, id, createdAt };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: number, updatedEvent: Partial<InsertEvent>): Promise<Event | undefined> {
    const event = this.events.get(id);
    if (!event) return undefined;
    
    const updated: Event = { ...event, ...updatedEvent };
    this.events.set(id, updated);
    return updated;
  }

  async deleteEvent(id: number): Promise<boolean> {
    return this.events.delete(id);
  }

  // Attendee methods
  async getAttendees(eventId: number): Promise<Attendee[]> {
    return Array.from(this.attendees.values()).filter(
      (attendee) => attendee.eventId === eventId
    );
  }

  async getAttendee(id: number): Promise<Attendee | undefined> {
    return this.attendees.get(id);
  }

  async getAttendeeByEmailAndEvent(email: string, eventId: number): Promise<Attendee | undefined> {
    return Array.from(this.attendees.values()).find(
      (attendee) => attendee.email === email && attendee.eventId === eventId
    );
  }

  async createAttendee(insertAttendee: InsertAttendee): Promise<Attendee> {
    const id = this.currentAttendeeId++;
    const createdAt = new Date();
    const attendee: Attendee = { ...insertAttendee, id, createdAt };
    this.attendees.set(id, attendee);
    return attendee;
  }

  async updateAttendee(id: number, updatedAttendee: Partial<InsertAttendee>): Promise<Attendee | undefined> {
    const attendee = this.attendees.get(id);
    if (!attendee) return undefined;
    
    const updated: Attendee = { ...attendee, ...updatedAttendee };
    this.attendees.set(id, updated);
    return updated;
  }

  async deleteAttendee(id: number): Promise<boolean> {
    return this.attendees.delete(id);
  }

  // Notification methods
  async getNotifications(eventId: number): Promise<Notification[]> {
    return Array.from(this.notifications.values()).filter(
      (notification) => notification.eventId === eventId
    );
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = this.currentNotificationId++;
    const sentAt = new Date();
    const notification: Notification = { ...insertNotification, id, sentAt };
    this.notifications.set(id, notification);
    return notification;
  }
}

export const storage = new MemStorage();
